from pydantic import BaseModel

class MongoBaseSchema(BaseModel):
    pass

class BaseRequestSchema(BaseModel):
    pass
