import base64

class Secrets:
    LOCK_OUT_TIME_MINS = 60
    UNIQUE_KEY = "MereDilNaalLaareNiTuLaunWaliye"
    ISSUER = "Imran"
    ALG = "HS256"
