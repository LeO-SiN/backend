class DatabasesNames:
    notebook = "notebook"
    users = "users"


class CollectionNames:
    notes = "notes"
    users = "users"